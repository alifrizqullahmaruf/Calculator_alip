package com.alif.calculator_alip;

import android.app.Activity;

public class MainActivity extends Activity {
}
